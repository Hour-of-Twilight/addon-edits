local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "deDE")
if not L then return end

L["STRING_ADDEDOKAY"] = "Erfolgreich hinzugefügt."
L["STRING_CONFIRM"] = "Bestätigt"
L["STRING_NEWTAB"] = "Neuer Tab"
L["STRING_OPTIONS"] = "Chart Viewer Optionen"
L["STRING_OPTIONS_SHOWICON"] = "Zeige Icon"
L["STRING_OPTIONS_WINDOWSCALE"] = "Fenstergröße"
L["STRING_PLUGIN_DESC"] = [=[Daten anzeigen, die durch Details erfasst wurden, als einfaches Liniendiagrammen!
]=]
L["STRING_PLUGIN_NAME"] = "Chart Viewer"
L["STRING_TOOLTIP"] = "Öffne Chart Viewer"
L["STRING_TOOSHORTNAME"] = "Der Name ist zu kurz."

