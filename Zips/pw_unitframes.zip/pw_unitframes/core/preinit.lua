local addonName, addon = ...;

--[[
/**
 * preinit addon
 * https://github.com/s0h2x/
 *  (c) 2022, s0h2x
 *
 * This file is provided as is (no warranties).
 */
]]

_G[addonName] = addon